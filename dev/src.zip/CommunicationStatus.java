/**
 * socket通信状态枚举类
 */
public enum CommunicationStatus {

    CLOSE,
    ESTABLISHED,
    ERROR;
}
