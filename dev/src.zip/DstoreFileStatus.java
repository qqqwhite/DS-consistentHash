/**
 * dstore文件情况枚举类
 */
public enum DstoreFileStatus {
    STORE_IN_PROGRESS,
    STORE_COMPLETE,
    REMOVE_IN_PROGRESS,
    REMOVE_COMPLETE;
}
