import java.util.ArrayList;

public class DstoreFileWrapper {
    String fileName;
    Long fileSize;
}
