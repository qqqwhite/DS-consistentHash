public enum TransDStoreStatus {

    SEND,
    REMOVE

}
